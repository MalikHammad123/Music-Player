package com.example.assignment1_i180687;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class signin3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin3);
    }
}